// ===== DATA =====
const COLORS = ["#ef4444","#a855f7","#ec4899","#3b82f6","#06b6d4","#10b981","#84cc16","#eab308","#f97316"];

let lists = [
  { id: "personal", name: "Personal", color: "#ef4444" },
  { id: "work",     name: "Work",     color: "#06b6d4" },
  { id: "list1",    name: "List 1",   color: "#eab308" },
];

let tasks = [
  { id: 1, title: "Research content ideas",      list: "personal", dueDate: "",       tags: [],        subtasks: [],                                           done: false, desc: "" },
  { id: 2, title: "Create a database of guests", list: "work",     dueDate: "",       tags: [],        subtasks: [],                                           done: false, desc: "" },
  { id: 3, title: "Renew driver's license",       list: "personal", dueDate: "22-03-22", tags: [],     subtasks: [{ id: 1, title: "Book appointment", done: false }], done: false, desc: "" },
  { id: 4, title: "Consult accountant",           list: "list1",   dueDate: "",       tags: ["Tag 1"], subtasks: [{ id: 1, title: "Prepare docs", done: false },{ id: 2, title: "Make call", done: false }], done: false, desc: "" },
  { id: 5, title: "Business plan review",         list: "work",    dueDate: "",       tags: [],        subtasks: [],                                           done: false, desc: "" },
];

let allTags = ["Tag 1", "Tag 2"];
let activeView = "today";
let selectedTaskId = null;
let selectedListColor = COLORS[0];

// ===== INIT =====
window.onload = function () {
  buildColorPicker();
  renderSidebar();
  renderTasks();
};

// ===== SIDEBAR =====
function renderSidebar() {
  renderListNav();
  renderTagsRow();
  updateBadges();
}

function renderListNav() {
  const container = document.getElementById("listNav");
  container.innerHTML = "";
  lists.forEach(list => {
    const div = document.createElement("div");
    div.className = "nav-item" + (activeView === list.id ? " active-nav" : "");
    div.onclick = () => setView(list.id);
    div.innerHTML = `
      <span class="list-dot" style="background:${list.color};width:10px;height:10px;border-radius:50%;display:inline-block;"></span>
      ${list.name}
      <span class="badge" style="margin-left:auto;">${tasks.filter(t => t.list === list.id).length}</span>`;
    container.appendChild(div);
  });
}

function renderTagsRow() {
  const row = document.getElementById("tagsRow");
  row.innerHTML = "";
  const bg = ["#fce7f3","#d1fae5","#e0f2fe","#fef9c3"];
  allTags.forEach((tag, i) => {
    const span = document.createElement("span");
    span.className = "tag-chip";
    span.style.background = bg[i % bg.length];
    span.textContent = tag;
    row.appendChild(span);
  });
  const add = document.createElement("span");
  add.style.cssText = "font-size:13px;color:#6b7280;cursor:pointer;";
  add.textContent = "+ Add Tag";
  row.appendChild(add);
}

function updateBadges() {
  document.getElementById("badge-today").textContent = tasks.length;
  document.getElementById("badge-upcoming").textContent = tasks.length;
  document.querySelectorAll(".active-nav").forEach(el => el.classList.remove("active-nav"));
  const activeEl = document.getElementById("nav-" + activeView) || document.querySelector(".nav-item.active-nav");
  if (document.getElementById("nav-" + activeView)) {
    document.getElementById("nav-" + activeView).classList.add("active-nav");
  }
  document.getElementById("taskCount").textContent = getFilteredTasks().length;
}

function setView(view) {
  activeView = view;
  selectedTaskId = null;
  closeEditPanel();
  const titles = { today: "Today", upcoming: "Upcoming", calendar: "Calendar", sticky: "Sticky Wall" };
  document.getElementById("viewTitle").textContent = titles[view] || (lists.find(l => l.id === view)?.name || "Today");
  renderSidebar();
  renderTasks();
}

function toggleSidebar() {
  const sidebar = document.getElementById("sidebar");
  const toggle = document.getElementById("menuToggle");
  sidebar.classList.toggle("hidden");
  toggle.style.display = sidebar.classList.contains("hidden") ? "block" : "none";
}

// ===== NEW LIST =====
function buildColorPicker() {
  const picker = document.getElementById("colorPicker");
  COLORS.forEach((c, i) => {
    const dot = document.createElement("div");
    dot.className = "color-dot" + (i === 0 ? " selected" : "");
    dot.style.background = c;
    dot.onclick = () => {
      document.querySelectorAll(".color-dot").forEach(d => d.classList.remove("selected"));
      dot.classList.add("selected");
      selectedListColor = c;
    };
    picker.appendChild(dot);
  });
}

function showNewListForm() { document.getElementById("newListForm").style.display = "block"; }
function hideNewListForm() { document.getElementById("newListForm").style.display = "none"; document.getElementById("newListName").value = ""; }

function addList() {
  const name = document.getElementById("newListName").value.trim();
  if (!name) return;
  lists.push({ id: Date.now().toString(), name, color: selectedListColor });
  hideNewListForm();
  renderSidebar();
}

// ===== TASKS =====
function getFilteredTasks() {
  const query = document.getElementById("searchInput").value.toLowerCase();
  let result = tasks;
  if (activeView !== "today" && activeView !== "upcoming") {
    result = result.filter(t => t.list === activeView);
  }
  if (query) result = result.filter(t => t.title.toLowerCase().includes(query));
  return result;
}

function renderTasks() {
  const container = document.getElementById("taskList");
  container.innerHTML = "";
  const filtered = getFilteredTasks();
  document.getElementById("taskCount").textContent = filtered.length;

  filtered.forEach(task => {
    const list = lists.find(l => l.id === task.list);
    const card = document.createElement("div");
    card.className = "task-card" + (selectedTaskId === task.id ? " selected" : "");
    card.onclick = () => openEditPanel(task.id);

    card.innerHTML = `
      <div class="task-check ${task.done ? 'done' : ''}" onclick="event.stopPropagation(); toggleDone(${task.id})">
        ${task.done ? "✓" : ""}
      </div>
      <div class="task-body">
        <div class="task-title ${task.done ? 'done' : ''}">${task.title}</div>
        <div class="task-meta">
          ${task.dueDate ? `<span>📅 ${task.dueDate}</span>` : ""}
          ${task.subtasks.length > 0 ? `<span>📋 ${task.subtasks.length} Subtask${task.subtasks.length > 1 ? 's' : ''}</span>` : ""}
          ${task.tags.map(t => `<span class="tag-badge">${t}</span>`).join("")}
          ${list ? `<span class="list-dot" style="background:${list.color};"></span>` : ""}
        </div>
      </div>
      <span class="arrow-icon">›</span>`;
    container.appendChild(card);
  });
  renderSidebar();
}

function toggleDone(id) {
  const t = tasks.find(t => t.id === id);
  if (t) t.done = !t.done;
  renderTasks();
}

function addTask() {
  const input = document.getElementById("newTaskInput");
  const title = input.value.trim();
  if (!title) return;
  const listId = (activeView === "today" || activeView === "upcoming") ? "personal" : activeView;
  tasks.push({ id: Date.now(), title, list: listId, dueDate: "", tags: [], subtasks: [], done: false, desc: "" });
  input.value = "";
  renderTasks();
}

// ===== EDIT PANEL =====
function openEditPanel(id) {
  selectedTaskId = id;
  const task = tasks.find(t => t.id === id);
  if (!task) return;

  document.getElementById("editPanel").style.display = "block";
  document.getElementById("editTitle").value = task.title;
  document.getElementById("editDesc").value = task.desc;
  document.getElementById("editDueDate").value = task.dueDate;

  // Populate list dropdown
  const sel = document.getElementById("editList");
  sel.innerHTML = "";
  lists.forEach(l => {
    const opt = document.createElement("option");
    opt.value = l.id;
    opt.textContent = l.name;
    if (l.id === task.list) opt.selected = true;
    sel.appendChild(opt);
  });

  // Tags
  const tagsDiv = document.getElementById("editTags");
  tagsDiv.innerHTML = "";
  task.tags.forEach(tag => {
    const span = document.createElement("span");
    span.className = "tag-badge";
    span.textContent = tag;
    tagsDiv.appendChild(span);
  });
  const addTag = document.createElement("span");
  addTag.style.cssText = "font-size:13px;color:#6b7280;cursor:pointer;margin-left:6px;";
  addTag.textContent = "+ Add Tag";
  tagsDiv.appendChild(addTag);

  renderSubtasks(task);
  renderTasks();
}

function renderSubtasks(task) {
  const container = document.getElementById("subtaskList");
  container.innerHTML = "";
  task.subtasks.forEach(sub => {
    const div = document.createElement("div");
    div.className = "subtask-item";
    div.innerHTML = `
      <div class="subtask-check ${sub.done ? 'done' : ''}" onclick="toggleSubtask(${task.id}, ${sub.id})"></div>
      <span>${sub.title}</span>
      <span style="color:#d1d5db;">›</span>`;
    container.appendChild(div);
  });
}

function toggleSubtask(taskId, subId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;
  const sub = task.subtasks.find(s => s.id === subId);
  if (sub) sub.done = !sub.done;
  renderSubtasks(task);
}

function addSubtask() {
  const task = tasks.find(t => t.id === selectedTaskId);
  if (!task) return;
  const title = prompt("Subtask title:");
  if (!title) return;
  task.subtasks.push({ id: Date.now(), title, done: false });
  renderSubtasks(task);
}

function saveCurrentTask() {
  const task = tasks.find(t => t.id === selectedTaskId);
  if (!task) return;
  task.title = document.getElementById("editTitle").value;
  task.desc = document.getElementById("editDesc").value;
  task.dueDate = document.getElementById("editDueDate").value;
  task.list = document.getElementById("editList").value;
  closeEditPanel();
  renderTasks();
}

function deleteCurrentTask() {
  tasks = tasks.filter(t => t.id !== selectedTaskId);
  closeEditPanel();
  renderTasks();
}

function closeEditPanel() {
  selectedTaskId = null;
  document.getElementById("editPanel").style.display = "none";
  renderTasks();
}

// ===== SETTINGS =====
function openSettings()  { document.getElementById("settingsModal").style.display = "flex"; }
function closeSettings() { document.getElementById("settingsModal").style.display = "none"; }
